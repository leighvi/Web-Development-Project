$( document ).ready(function() {
	$("#container").load( "html/login/login.html #login" );
});

function changeSub(page){
	if(page==="login"){
		$("#container").load( "html/login/login.html #login" );
	}
	else if(page==="register"){
		$("#container").load( "html/login/login.html #register" );
	}
}

function validateRegister(){
	var fname = $("[name='fname']").val();
	var sname = $("[name='sname']").val();
	var uname = $("[name='uname']").val();
	var email = $("[name='email']").val();
	var pass1 = $("[name='p1']").val();
	var pass2 = $("[name='p2']").val();

	if(fname===null || fname==="" || sname==null || sname===""
		|| uname===null || email==="" || email===null || email===""
		|| pass1===null || pass1==="" || pass2===null || pass2==="")
	{
		$("#inRegister").html("Please fill out all fields.");
	}
	else{
		if(pass1!==pass2){
			$("#inRegister").html("Passwords do not match.");
		}
		else{
			$("#register").submit();
		}
	}
}

function validateLogin(){
	var uname = $("[name='uname']").val();
	var pass = $("[name='pass']").val();

	if(uname==="" || uname===null || pass===null || pass===""){
		$("#inLogin").html("Please fill out all fields.");
	}
	else{
		$("#login").submit();
	}
}