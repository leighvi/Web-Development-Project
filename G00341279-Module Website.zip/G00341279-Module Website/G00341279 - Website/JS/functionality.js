function review(username){
	//save data from form
	var revText= $("#txt-area").val();

	//check for blank data
	if(revText===""){
		alert("Please fill out a review.");
	}

	else{
		//get time stamp
		var dt = new Date();

		//remove form from page
		$("#review-form").remove();

		//add table containing review in place of form
		$("#review-contain").append('<div class="rForm"><table class="rev-table"><tr><th id="rev-name"><th></tr><tr><td id="rev-text"></td></tr></table></div>');
		$("#rev-name").html(username + "<br>" + dt);
		$("#rev-text").html(revText);
	}
}

function addToCart(id,gameTitle,gamePrice){
	

	if(localStorage.getItem("cart"+id)){
		var cart = JSON.parse(localStorage.getItem("cart"+id));
		var itemInCart = false;

		for(var i=0;i<cart.length;i++){
			if(cart[i].title === gameTitle){
				cart[i].quantity++;
				itemInCart=true;
			}
		}

		if(!itemInCart){
			var game = {
				title: gameTitle,
				price: gamePrice,
				quantity: 1
			};

			cart.push(game);
		}

		localStorage.setItem("cart"+id,JSON.stringify(cart));
	}
	else{
		var newCart = [];

		var game = {
			title: gameTitle,
			price: gamePrice,
			quantity: 1
		};

		newCart.push(game);

		localStorage.setItem("cart"+id,JSON.stringify(newCart));
	}
}