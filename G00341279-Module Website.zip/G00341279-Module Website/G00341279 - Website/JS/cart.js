function removeItem(e){
	var target = e.target || e.srcElement;
	var trTarget = target.parentNode;

	if(trTarget.className === "cart-item"){
		var userID = "";

		$.ajax({ 
			url: 'getID.php',
	        type: 'post',
	        async: false,
	        success: function(output) {
	                    userID = output;
	                }
		});

		var cart = JSON.parse(localStorage.getItem("cart"+userID));
		for(var i=0;i<cart.length;i++){
			if(cart[i].title === trTarget.firstChild.innerHTML){
				cart.splice(i,1);
				if(cart.length>0){
					localStorage.setItem("cart"+userID,JSON.stringify(cart));
				}
				else{
					localStorage.removeItem("cart"+userID);
				}
				break;
			}
		}

		var tblTarget = trTarget.parentNode;
		tblTarget.removeChild(trTarget);
	}
	
	updateCart();

	e.preventDefault()
}

function updateCart(){
	var userID = "";

	$.ajax({ 
		url: 'getID.php',
        type: 'post',
        async: false,
        success: function(output) {
                    userID = output;
                }
	});

	if(localStorage.getItem("cart"+userID)){
		var userCart = JSON.parse(localStorage.getItem("cart"+userID));
		var cartTable = "<table class='cart-table' id='cart-table'><tr><th>Item</th><th>Price(&euro;)</th><th>Quantity</th></tr>";
		var cartTotal = 0;

		for(var i=0;i<userCart.length;i++){
			cartTable += "<tr class='cart-item'><td>" + userCart[i].title + "</td><td>" + parseFloat(userCart[i].price).toFixed(2) + "</td><td>" + userCart[i].quantity + "</td></tr>";
			cartTotal +=  parseFloat(userCart[i].price)*parseFloat(userCart[i].quantity);
		}

		cartTable += "<tr><td colspan='3'>Cart Total = &euro;" + parseFloat(cartTotal).toFixed(2) + "</td></tr></table>"

		cartTable += "<br><button type='button' class='cart-button checkout-button' onclick='checkout()'>Checkout</button> Go to Payment"

		$("#cart").html(cartTable);
	}
	else{
		var blankCart = "<table class='cart-table' id='cart-table'><tr><th>Item</th><th>Price</th><th>Quantity</th></tr><tr><td colspan='3'>Total = &euro;0.00</td></tr></table>";
		$("#cart").html(blankCart);
	}

	//add event listener after table creation
	var el = document.getElementById("cart-table");
	el.addEventListener('click',
	removeItem,
	false);

}

function checkout(){
	document.location.href = "checkout.php";
}

$(function(){
	updateCart();
})