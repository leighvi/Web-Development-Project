function clickCheck(){
	$isValid = false;

	$("#ccNum").validateCreditCard(function(result){
		result.valid ? $isValid=true : $isValid=false;

		if($("#cname")==="" || $("#cname")===null){
			$isValid=false;
		}
	});

	if($isValid){
		var userID = "";

		$.ajax({ 
			url: 'getID.php',
	        type: 'post',
	        async: false,
	        success: function(output) {
	                    userID = output;
	                }
		});

		localStorage.removeItem("cart"+userID);
		$("#payment").submit();
	}
	else{
		$("#invalid").html("Details are invalid");
	}
}

$(function(){
	var userID = "";

	$.ajax({ 
		url: 'getID.php',
        type: 'post',
        async: false,
        success: function(output) {
                    userID = output;
                }
	});

	var userCart = JSON.parse(localStorage.getItem("cart"+userID));
	
	var cartTotal = 0;

	for(var i=0;i<userCart.length;i++){
		cartTotal +=  parseFloat(userCart[i].price)*parseFloat(userCart[i].quantity);
	}

	$("#total").html("Cart Total = " + parseFloat(cartTotal).toFixed(2));
	$("#hiddenTotal").html("<input type='hidden' name='hiddenTotal' value='" +  parseFloat(cartTotal).toFixed(2) + "'/>")
})