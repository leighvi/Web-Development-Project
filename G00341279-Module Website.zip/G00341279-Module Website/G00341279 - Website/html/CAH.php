<?php
	session_start();

	$page_title = 'Cards Against Humanity';
	include ('includes/header.html');
?>

		<!--Page body-->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4"><img class="img-responsive" src="https://cf.geekdo-images.com/images/pic1104600.jpg"></div>
				<div class="col-md-8 table-border">
					<table class="info-table">
						<tr>
							<th>Publisher</th>
							<td><a href="http://www.cardsagainsthumanity.com/">Cards Against Humanity</a></td>
						</tr>
						<tr>
							<th>Year Published</th>
							<td>2009</td>
						</tr>
						<tr>
							<th># of Players</th>
							<td>4-30</td>
						</tr>
						<tr>
							<th>Recommended # of Players</th>
							<td>4 - 12</td>
						</tr>
						<tr>
							<th>Play Time</th>
							<td>30-60 Min</td>
						</tr>
						<tr>
							<th>Suggested Age</th>
							<td>16+</td>
						</tr>
						<tr>
							<th>Category</th>
							<td>Card Game, Humor, Mature/Adult, <span id="party">Party Game</span></td>
						</tr>
						<tr>
							<th>Expansion</th>
							<td>
								<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: First Expansion</a><br>
								<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Second Expansion</a><br>
								<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Third Expansion</a><br>
								<a data-toggle="collapse" data-target="#honors-tgt">See more</a>
								<div id="honors-tgt" class="collapse">
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Fourth Expansion</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Fifth Expansion</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Sixth Expansion</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: The Bigger, Blacker Box</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: World Wide Web Pack</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: 90s Nostalgia Pack</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Fantasy Pack</a><br>
									<a href="https://store.cardsagainsthumanity.com/">Cards Against Humanity: Science Pack</a><br>
								</div>
							</td>
						</tr>
						<tr>
							<th>Honors</th>
							<td>None</td>	
						</tr>	
					</table>
				</div><!--table div-->
			</div>
			<div class="row row-grid">
				<div class="col-xs-12 col-md-12 table-border">
					<table class="desc-table">
						<tr>
							<th>
								Description
							</th>
						</tr>
						<tr>
							<td>
								"A party game for horrible people."<br><br>

								Play begins with a judge, known as the "Card Czar", choosing a black question or fill-in-the-blank card from the top of the deck and showing it to all players. Each player holds a hand of ten white answer cards at the beginning of each round, and passes a card (sometimes two) to the Card Czar, face-down, representing their answer to the question on the card. The card czar determines which answer card(s) are funniest in the context of the question or fill-in-the-blank card. The player who submitted the chosen card(s) is given the question card to represent an "Awesome Point", and then the player to the left of the new Card Czar becomes the new Czar for the next round. Play continues until the players agree to stop, at which point the player with the most Awesome Points is the winner.<br><br>

								This, so far, sounds like the popular and fairly inoffensive Apples to Apples. While the games are similar, the sense of humor required is very different. The game encourages players to poke fun at practically every awkward or taboo subject including race, religion, gender, poverty, torture, alcoholism, drugs, sex (oh yes), abortion, child abuse, celebrities, and those everyday little annoyances like "Expecting a burp and vomiting on the floor".<br><br>

								In addition, there are a few extra rules. First, some question cards are "Pick 2" or cards, which require each participant to submit two cards in sequence to complete their answer. Second, a gambling component also exists. If a question is played which a player believes they have two possible winning answers for, they may bet an Awesome Point to play a single second answer. If the player who gambled wins, they retain the wagered point, but if they lose, the player who contributed the winning answer takes both points.<br><br>

								From the website:<br><br>

								"Cards Against Humanity is distributed under a Creative Commons Attribution-Noncommercial-Share Alike license - that means you can use and remix the game for free, but you can't sell it. Feel free to contact us at cardsagainsthumanity@gmail.com."
							</td>
						</tr>
					</table>
				</div>
			</div><!--description row-->
			<div class="row row-grid">
				<div class="col-md-6">
					<h3 class="video-capt">Cards Against Humanity Unboxing</h3>
					<div class="embed-responsive embed-responsive-16by9">
  						<iframe src="https://www.youtube.com/embed/BJP_XO7MM1M" allowfullscreen></iframe>
					</div>
				</div>
				<div class="col-md-6">
					<h3 class="video-capt" id="cahvid">Cards Against Humanity Gameplay</h3>
					<div class="embed-responsive embed-responsive-16by9">
  						<iframe src="https://www.youtube.com/embed/QCEqUn7If44" allowfullscreen></iframe>
					</div>
				</div>
			</div><!--video row-->

			<div class="row row-grid">
				<div class="col-md-12 col-xs-12 cart-div">
					<table class="cart-table">
						<tr>
							<th>
								Add item to cart:
							</th>
						</tr>
						<tr>
							<td>
								&euro; 24.99
							</td>
						</tr>
						<tr>
							<td>
								<button type="button" class="cart-button" onclick="addToCart('<?php echo $_SESSION['id']; ?>','<?php echo $page_title; ?>',24.99)">Add to cart</button>
							</td>
						</tr>
					</table>
				</div>
			</div>

<?php
	include('includes/review.html');

	include('includes/footer.html');
?>