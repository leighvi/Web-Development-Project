<?php
	session_start();

	$page_title = 'Cart';
	include('includes/cheader.html');
?>

	<div class="container-fluid">
		<div class="col-md-12 cart-div" id="cart">
		
		</div>
	</div>

<?php
	include ('includes/footer.html')
?>