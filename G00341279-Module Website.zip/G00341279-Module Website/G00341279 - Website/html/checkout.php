<?php
	session_start();

	$page_title = 'Checkout';
	include('includes/coheader.html');
?>

	<div class="container-fluid">
		<div class="col-md-12 cart-div">

			<form action="confirmCheckout.php" method="post" id="payment" class="lForm">
				<fieldset class=".col-md-6 .offset-md-3 .col-xs-6">
					<legend>Enter your payment details to checkout:</legend>
					Card Name: <input type="text" id="cname" size="20" maxlength="40" class="lInput"/><br>
					Card Number: <input type="text" id='ccNum' size="16" maxlength="16" class="lInput" value="5105105105105100"/><br>
					<div id="hiddenTotal"></div>
					<br>
					<h3 id="total"></h3>
				</fieldset>
				<div>
					<button type="button" name="checkout" value="checkout" class="cart-button checkout-button" onclick="clickCheck()">checkout</button>
				</div>
			</form>

			<div id="invalid" class="lIncorrect">
			</div>
		</div>
	</div>

<?php
	include('includes/footer.html');
?>