<?php
	session_start();

	$page_title = 'King of Tokyo';
	include ('includes/header.html');
?>

		<!--Page body-->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4"><img class="img-responsive" src="https://cf.geekdo-images.com/images/pic761434.jpg"></div>
				<div class="col-md-8 table-border">
					<table class="info-table">
						<tr>
							<th>Publisher</th>
							<td><a href="http://www.iellogames.com/KingOfTokyo.html">IELLO Games</a></td>
						</tr>
						<tr>
							<th>Year Published</th>
							<td>2011</td>
						</tr>
						<tr>
							<th># of Players</th>
							<td>2 - 6</td>
						</tr>
						<tr>
							<th>Recommended # of Players</th>
							<td>4 - 5</td>
						</tr>
						<tr>
							<th>Play Time</th>
							<td>30 Min</td>
						</tr>
						<tr>
							<th>Suggested Age</th>
							<td>6+</td>
						</tr>
						<tr>
							<th>Category</th>
							<td>Dice, Fighting, <span id="sci">Science Fiction</span></td>
						</tr>
						<tr>
							<th>Expansion</th>
							<td>
								<a href="http://www.iellogames.com/KingOfTokyo-PowerUp.html">King of Tokyo: Power Up!</a><br>
								<a href="http://www.iellogames.com/KingOfTokyo-Halloween.html">King of Tokyo: Halloween</a>
							</td>
						</tr>
						<tr>
							<th>Honors</th>
							<td>
								2011 Golden Geek Best Party Board Game Nominee<br>
								2011 Japan Boardgame Prize Voters' Selection Nominee<br>
								2011 Lucca Games Best Family Game Nominee<br>
								<a data-toggle="collapse" data-target="#honors-tgt">See more</a>
								<div id="honors-tgt" class="collapse">
									2011 Lys Grand Public Finalist<br>
									2012 As d'Or - Jeu de l'Année Nominee<br>
									2012 Golden Geek Best Board Game Artwork/Presentation Nominee<br>
									2012 Golden Geek Best Children's Board Game Nominee<br>
									2012 Golden Geek Best Children's Game Winner<br>
									2012 Golden Geek Best Family Board Game Nominee<br>
									2012 Golden Geek Best Family Board Game Winner<br>
									2012 Golden Geek Best Party Board Game Nominee<br>
									2012 Golden Geek Best Party Game Winner<br>
									2012 Golden Geek Best Thematic Board Game Nominee<br>
									2012 Gouden Ludo Nominee<br>
									2012 Ludoteca Ideale Winner<br>
									2013 Boardgames Australia Awards Best International Game Nominee<br>
									2013 Guldbrikken Best Family Game Nominee<br>
									2013 Guldbrikken Best Family Game Winner<br>
									2013 Hra roku Nominee<br>
									2013 Juego del Año Tico Nominee<br>
									2013 Nederlandse Spellenprijs Best Family Game Nominee<br>
									2013 Nederlandse Spellenprijs Best Family Game Winner<br>
								</div>
							</td>	
						</tr>	
					</table>
				</div><!--table div-->
			</div>
			<div class="row row-grid">
				<div class="col-xs-12 col-md-12 table-border">					
					<table class="desc-table">
						<tr>
							<th>
								Description
							</th>
						</tr>
						<tr>
							<td>
								In King of Tokyo, you play mutant monsters, gigantic robots, and strange aliens—all of whom are destroying Tokyo and whacking each other in order to become the one and only King of Tokyo.<br><br>

								At the start of each turn, you roll six dice, which show the following six symbols: 1, 2, or 3 Victory Points, Energy, Heal, and Attack. Over three successive throws, choose whether to keep or discard each die in order to win victory points, gain energy, restore health, or attack other players into understanding that Tokyo is YOUR territory.<br><br>

								The fiercest player will occupy Tokyo, and earn extra victory points, but that player can't heal and must face all the other monsters alone!<br><br>

								Top this off with special cards purchased with energy that have a permanent or temporary effect, such as the growing of a second head which grants you an additional die, body armor, nova death ray, and more.... and it's one of the most explosive games of the year!<br><br>

								In order to win the game, one must either destroy Tokyo by accumulating 20 victory points, or be the only surviving monster once the fighting has ended.
							</td>
						</tr>
					</table>
				</div>
			</div><!--description row-->
			<div class="row row-grid">
				<div class="col-md-6">
					<h3 class="video-capt">King of Tokyo Unboxing</h3>
					<div class="embed-responsive embed-responsive-16by9">
  						<iframe src="https://www.youtube.com/embed/n7KLEnzWr5Q" allowfullscreen></iframe>
					</div>
				</div>
				<div class="col-md-6">
					<h3 class="video-capt" id="kotvid">King of Tokyo Gameplay</h3>
					<div class="embed-responsive embed-responsive-16by9">
  						<iframe src="https://www.youtube.com/embed/BGaCjM2hal4" allowfullscreen></iframe>
					</div>
				</div>
			</div><!--video row-->

			<div class="row row-grid">
				<div class="col-md-12 col-xs-12 cart-div">
					<table class="cart-table">
						<tr>
							<th>
								Add item to cart:
							</th>
						</tr>
						<tr>
							<td>
								&euro; 45.00
							</td>
						</tr>
						<tr>
							<td>
								<button type="button" class="cart-button" onclick="addToCart('<?php echo $_SESSION['id']; ?>','<?php echo $page_title; ?>',45.00)">Add to cart</button>
							</td>
						</tr>
					</table>
				</div>
			</div>

<?php
	include('includes/review.html');

	include('includes/footer.html');
?>