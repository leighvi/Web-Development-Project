<?php
	session_start();

	$page_title = 'Checkout';
	include('includes/coheader.html');
	require "login/mysqli_connect.php";
	
	$total = $_POST['hiddenTotal'];

	$query = "insert into sales(user_id,total) 
		values ('" . $_SESSION['id'] ."','" . $total . "');";

	$request = @mysqli_query($dbc, $query);

	$_SESSION["saleid"] = mysqli_insert_id($dbc);

	mysqli_close($dbc);
?>
	
	<div class="container-fluid">
		<div class="col-md-12 check-confirm-div">
			<?php echo "<h1>Thank you for your purchase</h1><h3>Your order id is:</h3><h2>" . $_SESSION["saleid"] . "</h2>" ?>
		</div>
	</div>

<?php
	include('includes/footer.html');
?>