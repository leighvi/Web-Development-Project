<?php
	session_start();

	require "mysqli_connect.php";

	$uname = $_POST['uname'];
	$pass = $_POST['pass'];

	$query = "select user_ID from users where username='" . $uname . "' and 
		password='" . sha1($pass) . "';";

	$request = @mysqli_query($dbc, $query);

	$rows = @mysqli_num_rows($request);

	if($rows==1){
		while($obj=mysqli_fetch_array($request)){
			$_SESSION["id"] = $obj['user_ID'];
		}
		$_SESSION["uname"] = $uname;
		header('location: ../frontpage.php');
	}
	else{
		echo '<h1>Error!</h1><p class="error">The username and password entered do not match any on file!</p><br>';
		echo '<button onclick="history.go(-1);">Back</button>';
	}

	mysqli_close($dbc);
?>