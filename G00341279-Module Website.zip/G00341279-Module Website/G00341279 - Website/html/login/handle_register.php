<?php
	
	session_start();

	require "mysqli_connect.php";

	$fname = $_POST['fname'];
	$sname = $_POST['sname'];
	$uname = $_POST['uname'];
	$email = $_POST['email'];
	$pass = $_POST['p1'];

	$query = "insert into users(first_name,surname,email,username,password) 
		values ('" . $fname ."','" . $sname . "','" . $email . "','" . $uname . 
			"','" . sha1($pass) . "');";

	$request = @mysqli_query($dbc, $query);

	$_SESSION["id"] = mysqli_insert_id($dbc);
	$_SESSION["uname"] = $uname;

	mysqli_close($dbc);

	header('Location: ../frontpage.php');
?>