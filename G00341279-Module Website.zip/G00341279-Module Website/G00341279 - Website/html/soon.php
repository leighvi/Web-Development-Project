<?php
	session_start();

	$page_title = 'Comming Soon';
	include ('includes/header.html');
?>

		<!--Page body-->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<h2>Note: This page will be updated as soon as new information becomes available!</h2><br>
					<ol>
						<li><a href="https://www.kickstarter.com/projects/steamforged/dark-soulstm-the-board-game">Dark Souls: The Board Game</a></li>
							<ul>
								<li>Release Date: TBA 2017</li>
								<li># of Players: 1–4</li>
								<li>Description: <br>Dark Souls&trade; - The Board Game is a strategically challenging, deeply immersive combat exploration game for 1-4 players set in the Dark Souls&trade; universe. Players choose from a number of core character classes and explore dangerous locations full of monsters, treasures, and deadly boss fights.<br>
								Designed specifically for the Dark Souls&trade; universe and introducing a number of innovative gameplay mechanics, with world-class miniatures faithful to the rich universe, this game delivers an experience that captures the very essence of the original video games.</li>
							</ul>
						<br>
						<li>Great Scott!</li>
							<ul>
								<li>Release Date: TBA</li>
								<li># if Players: 3–5</li>
								<li>Play Time: 20–45 Min</li>
								<li>Suggested Age: 14+</li>
								<li>Description: <br>Great Scott! - The Game of Mad Invention is a Victorian themed card game of rival mad inventors.<br>

								In Great Scott!, the whimsical 19th century parlour game that never was, 3-5 players build five card inventions with an eye to victory in the inventor’s contest at the Great Exhibition. Combine Animal, Mineral, and Vegetable assets with Destructive, Productive, and Transportive concepts to create one of the greatest inventions not known to mankind!<br>

								In a game of Great Scott!, players draft cards and add components to their invention. Matching sets of asset and concept cards give bonus points, but the biggest prizes are awarded for alliteration. Then, when your invention is finished, explain what it does and how it works to get extra points from the other inventors.<br>

								Great Scott! is easy to learn, fast to play, and is guaranteed to amuse!<br>

								Will your Bedazzling Bat Borne Brass Balloon outdo your rival’s Diabolical Dynamite Driven Duck Dispatcher? Perhaps, if you play your cards right…<br>

								Consider carefully; clever card combinations and amusing alliterative amalgamations bring bountiful bonuses!<br>

								For Her Majesty, and for science!</li>
					
				</div>
			</div>
			
<?php
	include('includes/footer.html');
?>