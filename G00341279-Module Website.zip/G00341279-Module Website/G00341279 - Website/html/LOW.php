<?php
	session_start();

	$page_title = 'Lords of Waterdeep';
	include ('includes/header.html');
?>

		<!--Page body-->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4"><img class="img-responsive" src="https://cf.geekdo-images.com/images/pic1116080.jpg"></div>
				<div class="col-md-8 table-border">
					<table class="info-table">
						<tr>
							<th>Publisher</th>
							<td><a href="http://company.wizards.com/">Wizards of the Coast</a></td>
						</tr>
						<tr>
							<th>Year Published</th>
							<td>2012</td>
						</tr>
						<tr>
							<th># of Players</th>
							<td>2 - 5</td>
						</tr>
						<tr>
							<th>Recommended # of Players</th>
							<td>3 - 4</td>
						</tr>
						<tr>
							<th>Play Time</th>
							<td>60–120 Min</td>
						</tr>
						<tr>
							<th>Suggested Age</th>
							<td>12+</td>
						</tr>
						<tr>
							<th>Category</th>
							<td>City Building, <span id="fantasy">Fantasy</span></td>
						</tr>
						<tr>
							<th>Expansion</th>
							<td><a href="http://dnd.wizards.com/products/tabletop-games/board-games/scoundrels-skullport">Lords of Waterdeep: Scoundrels of Skullport</a></td>
						</tr>
						<tr>
							<th>Honors</th>
							<td>
								2012 Charles S. Roberts Best Science-Fiction or Fantasy Board Wargame Nominee<br>
								2012 ENnie for Best RPG Related Product Nominee<br>
								2012 ENnie for Best RPG Related Product Silver Winner<br>
								<a data-toggle="collapse" data-target="#honors-tgt">See more</a>
								<div id="honors-tgt" class="collapse">
									2012 Golden Geek Best Board Game Artwork/Presentation Nominee<br>
									2012 Golden Geek Best Family Board Game Nominee<br>
									2012 Golden Geek Best Strategy Board Game Nominee<br>
									2012 Guldbrikken Special Jury Prize Winner<br>
									2012 Meeples' Choice Nominee<br>
									2013 Origins Awards Best Board Game Nominee<br>
									2013 Origins Awards Best Board Game Winner
								</div>
							</td>	
						</tr>	
					</table>
				</div><!--table div-->
			</div>
			<div class="row row-grid">
				<div class="col-xs-12 col-md-12 table-border">
					<table class="desc-table">
						<tr>
							<th>
								Description
							</th>
						</tr>
						<tr>
							<td>
								Game description from the publisher:

								Waterdeep, the City of Splendors – the most resplendent jewel in the Forgotten Realms, and a den of political intrigue and shady back-alley dealings. In this game, the players are powerful lords vying for control of this great city. Its treasures and resources are ripe for the taking, and that which cannot be gained through trickery and negotiation must be taken by force!<br><br>

								In Lords of Waterdeep, a strategy board game for 2-5 players, you take on the role of one of the masked Lords of Waterdeep, secret rulers of the city. Through your agents, you recruit adventurers to go on quests on your behalf, earning rewards and increasing your influence over the city. Expand the city by purchasing new buildings that open up new actions on the board, and hinder – or help – the other lords by playing Intrigue cards to enact your carefully laid plans.<br><br>

								During the course of play, you may gain points or resources through completing quests, constructing buildings, playing intrigue cards or having other players utilize the buildings you have constructed. At the end of 8 rounds of play, the player who has accrued the most points wins the game.
							</td>
						</tr>
					</table>
					
				</div>
			</div><!--description row-->

			<div class="row row-grid">
				<div class="col-md-6">
					<h3 class="video-capt">Lords of Waterdeep Unboxing</h3>
					<div class="embed-responsive embed-responsive-16by9">
  						<iframe src="https://www.youtube.com/embed/_GNDtft7UeU" allowfullscreen></iframe>
					</div>
				</div>
				<div class="col-md-6">
					<h3 class="video-capt" id="lowvid">Lords of Waterdeep Gameplay</h3>
					<div class="embed-responsive embed-responsive-16by9">
  						<iframe src="https://www.youtube.com/embed/D7DvEIfrP84" allowfullscreen></iframe>
					</div>
				</div>
			</div><!--video row-->
			
			<div class="row row-grid">
				<div class="col-md-12 col-xs-12 cart-div">
					<table class="cart-table">
						<tr>
							<th>
								Add item to cart:
							</th>
						</tr>
						<tr>
							<td>
								&euro; 80.00
							</td>
						</tr>
						<tr>
							<td>
								<button type="button" class="cart-button" onclick="addToCart('<?php echo $_SESSION['id']; ?>','<?php echo $page_title; ?>',80.00)">Add to cart</button>
							</td>
						</tr>
					</table>
				</div>
			</div>
			
<?php
	include('includes/review.html');

	include('includes/footer.html');
?>