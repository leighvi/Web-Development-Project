<?php
	session_start();

	$page_title = 'Bored Games';
	include ('includes/fpheader.html');
?>

			<div class="row">
				<div class="col-md-3">
					<div class="sidemenu">
						<h4>Quick Links</h4>
						<br>
						<ul>
							<h5>Categories</h5>
							<li><a href="LOW.php#fantasy">Fantasy</a></li>
							<li><a href="KOT.php#sci">Science Fiction</a></li>
							<li><a href="CAH.php#party">Party Game</a></li>
						</ul>
						<br>
						<ul>
							<h5>Game Videos</h5>
							<li><a href="LOW.php#lowvid">Lords of Waterdeep</a></li>
							<li><a href="KOT.php#kotvid">King of Tokyo</a></li>
							<li><a href="CAH.php#cahvid">Cards Against Humanity</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-6">
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
							<li data-target="myCarousel" data-slide-to="1"></li>
							<li data-target="myCarousel" data-slide-to="2"></li>
						</ol>

						<div class="carousel-inner" role="listbox">
							<div class="item active">
								<img class="img-responsive" src="http://www.rpgbooster.com/wp-content/uploads/2013/05/waterdeep.jpg" alt="Lords of Waterdeep">
								<div class="carousel-caption capt-text">
							    	<h3>Lords of Waterdeep</h3>
							    	<p>Take on the role of one of the masked Lords of Waterdeep.</p>
							    </div>
							</div>
							<div class="item">
								<img class="img-responsive" src="http://couchpotatotalk.com/blog/wp-content/uploads/2013/11/king-of-tokyo.jpg" alt="King of Tokyo">
								<div class="carousel-caption capt-text">
							    	<h3>King of Tokyo</h3>
							    	<p >Only the fiercest player will occupy Tokyo.</p>
							    </div>
							</div>
							<div class="item">
								<img class="img-responsive" src="http://theglassmeeple.com/zstuff/uploads/CardsAgainstHumanity3.jpg" alt="Cards Against Humanity">
								<div class="carousel-caption capt-text">
							    	<h3>Cards Against Humanity</h3>
							    	<p>A party game for horrible people.</p>
							    </div>
							</div>
						</div>
					</div>
				</div><!--carousel-->
			</div>

<?php
	include('includes/footer.html');
?>