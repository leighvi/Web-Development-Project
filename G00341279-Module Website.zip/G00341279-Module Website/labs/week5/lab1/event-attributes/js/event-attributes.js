function checkUsername(){
	var username = document.getElementById("username");

	if(username.value.length<5){
		document.getElementById("feedback").innerHTML = "Username is less than 5 characters!";
	}
}