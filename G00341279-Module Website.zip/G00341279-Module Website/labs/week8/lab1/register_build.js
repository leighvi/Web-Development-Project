var el = document.getElementById("register_form");
el.addEventListener('load',
	createStr(),
	false);

function createStr(){
	newStr = "<form id=\"form1\">";
	newStr +="<table>";
	newStr += "<tr><td>Username:</td><td><input type=\"text\" id=\"uName\"></td></tr><br>";
	newStr += "<tr><td>Password:</td><td><input type=\"text\" id=\"pWord\"></td></tr><br>";
	newStr += "<tr><td>Re-enter Password:</td><td><input type=\"text\" id=\"pWordConfirm\"></td></tr></table><br>";
	newStr += "Gender: <input type=\"Radio\" name=\"gender\" value=\"male\" checked> Male";
	newStr += "<input type=\"Radio\" name=\"gender\" value=\"female\"> Female";
	newStr += "<input type=\"Radio\" name=\"gender\" value=\"other\"> Other<br><br>";
	newStr += "<button type=\"button\" onclick=\"doStuff()\">Submit</button>";
	newStr += "</form>";

	document.getElementById("register_form").innerHTML = newStr;
}