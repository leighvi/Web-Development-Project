var xhr = new XMLHttpRequest();
xhr.open("GET","data/data.json",true);
xhr.send(null);
xhr.onload = function(){

	if(xhr.status === 200){ //if server status is ok

		var responseObj = JSON.parse(xhr.responseText);
		var content ="";

		for(var i=0;i<responseObj.events.length;i++){
			content += "<div class=\"event\">";
			content += "<img src=\""+ responseObj.events[i].map + "\"";
			content += "alt=\"" + responseObj.events[i].location + "\"/>";
			content += "<p><b>" + responseObj.events[i].location + "</b><br>";
			content += responseObj.events[i].date + "</p>";
			content += "</div>";
		}

	}

	//updatethe page with new content
	document.getElementById("content").innerHTML = content;
};