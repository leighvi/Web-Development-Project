console.log('And we\'re off');

try{
	//someVar; // variable is not declared. Will cause an exception
	var someVar;
}catch(e){
	document.getElementById("error_details").innerHTML = "Error has been caught! Error details: "+ e;
}finally{
	alert("Finally executed!")
}

