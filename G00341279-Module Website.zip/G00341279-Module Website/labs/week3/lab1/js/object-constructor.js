var hotel = new Object();

hotel.name = 'Quay';
hotel.rooms = 40;
hotel.booked = 25;
hotel.gym = true;
hotel.roomTypes = ['twin','double','suite'];
hotel.checkAvailability = function(){
		return this.rooms - this.booked;
	};

document.getElementById("hotelName").innerHTML = hotel.name;
document.getElementById("rooms").innerHTML = hotel.checkAvailability();