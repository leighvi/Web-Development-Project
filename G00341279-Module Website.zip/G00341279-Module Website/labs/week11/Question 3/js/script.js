$(document).ready(function(){
  $.ajax({
    type:"GET",
    url:"https://rawgit.com/obrienke1/web_application_development/master/jsonp.js?callback=showSeasons",
    dataType:"jsonp",
    jsonpCallback: "showSeasons",
    success:function(data){
      var $content = '<h2>Seasons</h2><ul>';

      for (var i = 0; i < data.seasons.length; i++) {  
        $content += '<li><a href="#">' + data.seasons[i].season + '</a></li>';
      }

      $content += '</ul>';

      $("#listContent").html($content);
    },
    error: function(){
      alert("The jsonp file could not be accessed");
    }
  })
});
