$(document).ready(function(){
	var $finalContent = "";
	$.ajax({
		type:"GET",
		url:"data/league_table.json",
		dataType:"json",
		success:function(data){
		
		for(var i=0;i<data.standing.length;i++){
			
			//check if even row, +1 to iterator to get actual number
			var count = i+1;
			if(count%2===0){
				$finalContent += "<tr class='even'>";
			}
			else{
				$finalContent += "<tr>";
			}
			$finalContent += "<td>" + data.standing[i].Pos + "</td>";
			$finalContent += "<td>" + data.standing[i].Team + "</td>";
			$finalContent += "<td>" + data.standing[i].P + "</td>";
			$finalContent += "<td>" + data.standing[i].Pts + "</td>";
			$finalContent += "<td>" + data.standing[i].F + "</td>";
			$finalContent += "<td>" + data.standing[i].A + "</td>";
			$finalContent += "<td>" + data.standing[i].GD + "</td>";
			$finalContent += "<td>" + data.standing[i].W + "</td>";
			$finalContent += "<td>" + data.standing[i].D + "</td>";
			$finalContent += "<td>" + data.standing[i].L + "</td>";

			$finalContent += "</tr>";
		}

			$("#tableContent").html($finalContent);

		},
		error:function(){
			alert("The JSON file could not be accessed");
		}
	})
});