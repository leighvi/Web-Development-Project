var xhr = new XMLHttpRequest();
xhr.open("GET","data/league_table.json",true);
xhr.send(null);
xhr.onload = function(){

	if(xhr.status === 200){ //if server status is ok

		var responseObj = JSON.parse(xhr.responseText);
		var finalContent="";

		for(var i=0;i<responseObj.standing.length;i++){
			
			//check if even row, +1 to iterator to get actual number
			var count = i+1;
			if(count%2===0){
				finalContent += "<tr class='even'>";
			}
			else{
				finalContent += "<tr>";
			}
			finalContent += "<td>" + responseObj.standing[i].Pos + "</td>";
			finalContent += "<td>" + responseObj.standing[i].Team + "</td>";
			finalContent += "<td>" + responseObj.standing[i].P + "</td>";
			finalContent += "<td>" + responseObj.standing[i].Pts + "</td>";
			finalContent += "<td>" + responseObj.standing[i].F + "</td>";
			finalContent += "<td>" + responseObj.standing[i].A + "</td>";
			finalContent += "<td>" + responseObj.standing[i].GD + "</td>";
			finalContent += "<td>" + responseObj.standing[i].W + "</td>";
			finalContent += "<td>" + responseObj.standing[i].D + "</td>";
			finalContent += "<td>" + responseObj.standing[i].L + "</td>";

			finalContent += "</tr>";
		}

	}

	document.getElementById("tableContent").innerHTML = finalContent;
};