var num = 2.9999;

//document.writeln(num.toFixed(25));

//add a comment here giving details of the error this produces
/*
Console is returning a range error for the toFixed() function as the 
range for the function is between 0-20 and what is being tried is toFixed(25)
*/

//add code to handle this error - see Javascript Exception Handling Lab for example on how to do this.
 
try{
	document.writeln(num.toFixed(25));
}catch(e){
	console.log("Error has been caught.");
	console.log("Type of error: " + e.name);
	console.log("Description: " + e.message);
}finally{
	console.log("Continuing code execution.");
}
