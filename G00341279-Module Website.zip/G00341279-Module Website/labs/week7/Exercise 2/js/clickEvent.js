//add an click event listener to the table of nameList.html
var el = document.getElementById("t1");
el.addEventListener('click',
	removeItem,
	false);

//event listener to invoke this function:
function removeItem(e){
	// Add code here to remove rows clicked on. 
	var target = e.target || e.srcElement;
	var trTarget = target.parentNode;
	var tblTarget = trTarget.parentNode;

	tblTarget.removeChild(trTarget);
	
	//don't forget to stop propagation
	//rememeber event object
	e.preventDefault()
}

