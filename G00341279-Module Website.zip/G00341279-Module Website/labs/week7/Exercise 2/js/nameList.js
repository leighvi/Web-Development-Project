//add a load event listener to the body of nameList.html
var el = document.getElementById("namesListBody");
el.addEventListener('load',
	populate_page(),
	false);

//event listener to invoke this function:
function populate_page() {
	//Add code here to complete exercise to create the table and add it to div element on the page
	var tbl_Def = "<table border='1px solid black' id='t1'><tr><td>First Name</td><td>Surname</td><tr>";

	var name_Obj;
	for(var i=0; i<localStorage.length;i++){
		name_Obj = JSON.parse(localStorage.getItem("name_key_"+i));

		if(i===0){
			tbl_Def += "<tr><td><b>" + name_Obj.fName + 
			"</b></td><td><b>"+ name_Obj.lName + "</b></td><tr>";
		}
		else{
			tbl_Def += "<tr><td>" + name_Obj.fName + 
			"</td><td>"+ name_Obj.lName + "</td><tr>";
		}
		
	}

	tbl_Def += "</table>";

	document.getElementById("nameList").innerHTML = tbl_Def;


	//added the following to create a reference to js/clickEvent.js within <head> tag.
	var clickEventRef=document.createElement('script');
	clickEventRef.setAttribute("type","text/javascript");
	clickEventRef.setAttribute("src","js/clickEvent.js");
	document.getElementsByTagName("head")[0].appendChild(clickEventRef);
}
