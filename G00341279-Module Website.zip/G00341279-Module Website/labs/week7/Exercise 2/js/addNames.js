//create functions for add(), clear_storage() and names object
//add function to use localStorage object.
function names(f_Name,l_Name){
	this.fName = f_Name;
	this.lName = l_Name;
}

function add(){
	var nameKey = "name_key_" + localStorage.length;

	localStorage.setItem(nameKey,
		JSON.stringify(new names(document.getElementById("fld1").value,
			document.getElementById("fld2").value)
		));

	window.location.reload();
}

function clear_storage(){
	localStorage.clear();
}