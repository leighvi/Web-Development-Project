<?php
	//page title for header file
	$page_title = 'PHP Form Handler';
	include('header.html');

	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['comments'])){
		$name = $_POST['name'];
		$email = $_POST['email'];
		$comments = $_POST['comments'];

		echo nl2br("Thank you, <b>" . $name . "</b> for the following comments:\n<tt>" . $comments . "</tt>\n\n");
		echo nl2br("We will reply to you at <i>" . $email . "</i>\n\n");

		if(isset($_POST['interests'])){
			$interests = "";
			foreach ($_POST['interests'] as $val) {
				$interests .= $val . "\n";
			}

			echo nl2br("Your interests are:\n".$interests);
		}
		else{
			echo nl2br("You have no interests!\n");
		}
	}
	else{
		echo nl2br("Please go back and fill out the form again.\n");
		echo '<button onclick="history.go(-1);">Back</button>';
	}

	include('footer.html');
?>