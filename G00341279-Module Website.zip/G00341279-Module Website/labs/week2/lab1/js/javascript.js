function Add(){
	var n1 = parseInt(document.form1.num1.value);
	var n2 = parseInt(document.form1.num2.value);

	if(isNaN(n1 || n2)){
		alert("Didn't input number!");
	}
	else if(n1<=10){
		alert("Total of two numbers entered = " + (n1+n2));
	}
	else{
		alert("Num 1 is over 10!");
	}
}