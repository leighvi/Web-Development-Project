// add javascript code here for web storage lab exercise
function book(name){
	this.book = name;
};

function add(){
	var objKey = "obj_key_" + localStorage.length;

	localStorage.setItem(objKey,
		JSON.stringify(new book(document.book_form.bookName.value)));

	window.location.reload();
}

function clear_storage(){
	localStorage.clear();
}

function fromStorage(){
	for(var i=0; i<localStorage.length;i++){
		var obj = JSON.parse(localStorage.getItem("obj_key_"+i));
		alert(obj.book);
	}
}

