function itemRemove(e){
	var target = e.target || e.srcElement;
	var liTarget = target.parentNode;
	var ulTarget = liTarget.parentNode;

	ulTarget.removeChild(liTarget);
	e.preventDefault()
}

var el = document.getElementById("shoppingList");
el.addEventListener('click',itemRemove,false);