$(function(){
	$('div#page').html('<p>Something Here</p>');
});
