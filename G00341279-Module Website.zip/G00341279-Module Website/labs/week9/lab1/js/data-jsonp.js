function showEvents(data){

	var content = "";

	for(var i=0; i<data.events.length;i++){
		content += '<div class="event">';
		content += '<img src="' + data.events[i].map + '"';
		content += 'alt="' + data.events[i].location + '"/>';
		content += '<p><b>' + data.events[i].location + '</b><br>';
		content += data.events[i].date + '</p>';
		content += '</div>';
	}

	document.getElementById('content').innerHTML = content;
}