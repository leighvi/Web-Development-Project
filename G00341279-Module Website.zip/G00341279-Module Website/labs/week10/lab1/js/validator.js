$(function(){
	$isValid = false;

	$("#ccNum").validateCreditCard(function(result){
		result.valid ? $isValid=true : $isValid=false;	
	});

	$("#confirm").on("click",function(){
		$isValid ? $(window).attr("location","confirmed.html") : alert("Not Valid")
	});
})
