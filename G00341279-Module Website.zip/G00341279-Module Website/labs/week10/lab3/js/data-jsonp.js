$(document).ready(function(){
  $.ajax({
    type:"GET",
    url:"http://htmlandcssbook.com/js/jsonp.js?callback=showEvents",
    dataType:"jsonp",
    jsonpCallback: "showEvents",
    success:function(data){
      var $content = '';

      for (var i = 0; i < data.events.length; i++) {  
        $content += '<div class="event">';
        $content += '<img src="' + data.events[i].map + '" ';
        $content += 'alt="' + data.events[i].location + '" />';
        $content += '<p><b>' + data.events[i].location + '</b><br>';
        $content += data.events[i].date + '</p>';
        $content += '</div>';
      }

      $("#content").html($content);
    },
    error: function(){
      alert("The XML file could not be accessed");
    }
  })
});
