$(document).ready(function(){
	var $content = "";
	$.ajax({
		type:"GET",
		url:"data/data.xml",
		dataType:"xml",
		success:function(xml){
			$(xml).find('event').each(function(){
				$content += "<div class='event'\"'>";
				$content += "<img src='" + 
					$(this).find('map').text() + "'";
				$content += "alt='" + 
					$(this).find('location').text() + "'/>";
				$content += "<p><b>" + 
					$(this).find('location').text() + "</b><br>";
				$content += $(this).find('date').text() + "</p>";
				$content += "</div>";
			})
			$("#content").html($content);
		},
		error:function(){
			alert("The XML file could not be accessed");
		}
	})/*.done(function(xml){
		$(xml).find('event').each(function(){
			$content += "<div class='event'\"'>";
			$content += "<img src='" + 
				$(this).find('map').text() + "'";
			$content += "alt='" + 
				$(this).find('location').text() + "'/>";
			$content += "<p><b>" + 
				$(this).find('location').text() + "</b><br>";
			$content += $(this).find('date').text() + "</p>";
			$content += "</div>";
		})
		$("#content").html($content);
	})*/;
});